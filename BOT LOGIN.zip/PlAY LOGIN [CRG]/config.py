# Cyberspace bot

##This source serves as a base for Cyberspace store bots.
##It aims to be as modular as possible, allowing adding new features with minor effort.

## Example config file

##```python
# Your Telegram bot token.
BOT_TOKEN = "6111286631:AAHRF5TVvnDvJ5LtfMD2u1avMY-HBs792fw"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
API_ID = 611335
API_HASH = "d524b414d21f4d37f08684c1df41ac9c"

# Chat used for logging errors.
LOG_CHAT = -1001832405031

# Chat used for logging user actions (like buy, gift, etc).
ADMIN_CHAT = -1001832405031
GRUPO_PUB = -1001832405031

# How many updates can be handled in parallel.
# Don't use high values for low-end servers.
WORKERS = 50

# Admins can access panel and add new materials to the bot.
ADMINS = [5337430673, 5607245895, 5607245895, 5508410205]

# Sudoers have full access to the server and can execute commands.
SUDOERS = [5337430673, 5607245895, 5607245895, 5508410205]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = [5337430673, 5607245895, 5607245895, 5508410205]

# Bote o Username do bot sem o @
# Exemplo: default
BOT_LINK = "LoginsCaterva_bot"



# Bote o Username do suporte sem o @
# Exemplo: suporte
BOT_LINK_SUPORTE = "SnowLoginsCaterva"
##```
